# 🚀 FastAPI - Gerenciamento de Usuários e Recebimento de Dados

Este projeto contém duas APIs REST desenvolvidas com **FastAPI**:

1. 👥 **/users** — CRUD completo para gerenciar usuários (em memória)
2. 📩 **/data** — endpoint para receber dados genéricos em JSON

## ⚙️ Instalação e execução local

```bash
git clone https://github.com/SEU_USUARIO/fastapi-users-data-api.git
cd fastapi-users-data-api
pip install -r requirements.txt
uvicorn main:app --reload
```

Acesse:
- Swagger UI → http://127.0.0.1:8000/docs  
- ReDoc → http://127.0.0.1:8000/redoc  
