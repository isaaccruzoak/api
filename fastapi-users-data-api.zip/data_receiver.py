from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class DataInput(BaseModel):
    origem: str
    conteudo: dict

@router.post("/")
def receber_dados(data: DataInput):
    return {
        "message": "Dados recebidos com sucesso!",
        "dados": data
    }
