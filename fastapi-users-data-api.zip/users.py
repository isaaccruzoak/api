from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List

router = APIRouter()

class User(BaseModel):
    id: int
    nome: str
    email: str

users_db: List[User] = []

@router.get("/", response_model=List[User])
def listar_usuarios():
    return users_db

@router.post("/", response_model=User)
def criar_usuario(user: User):
    for u in users_db:
        if u.id == user.id:
            raise HTTPException(status_code=400, detail="ID já existe.")
    users_db.append(user)
    return user

@router.get("/{user_id}", response_model=User)
def obter_usuario(user_id: int):
    for user in users_db:
        if user.id == user_id:
            return user
    raise HTTPException(status_code=404, detail="Usuário não encontrado.")

@router.put("/{user_id}", response_model=User)
def atualizar_usuario(user_id: int, updated_user: User):
    for i, user in enumerate(users_db):
        if user.id == user_id:
            users_db[i] = updated_user
            return updated_user
    raise HTTPException(status_code=404, detail="Usuário não encontrado.")

@router.delete("/{user_id}")
def deletar_usuario(user_id: int):
    for i, user in enumerate(users_db):
        if user.id == user_id:
            del users_db[i]
            return {"message": "Usuário deletado com sucesso."}
    raise HTTPException(status_code=404, detail="Usuário não encontrado.")
