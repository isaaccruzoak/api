from fastapi import FastAPI
from users import router as users_router
from data_receiver import router as data_router

app = FastAPI(title="Gerenciamento de Usuários e Recebimento de Dados")

app.include_router(users_router, prefix="/users", tags=["Usuários"])
app.include_router(data_router, prefix="/data", tags=["Recebimento de Dados"])

@app.get("/")
def root():
    return {"message": "Bem-vindo à API FastAPI!"}
